#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <algorithm>

// Course class to hold course data
class Course {
public:
    std::string courseNumber;
    std::string courseTitle;
    std::vector<std::string> prerequisites;

    Course(std::string num, std::string title)
        : courseNumber(num), courseTitle(title) {}

    // Add prerequisite to the course
    void addPrerequisite(std::string prereq) {
        prerequisites.push_back(prereq);
    }
};

// Binary Search Tree Node to hold course
class BSTNode {
public:
    Course* course;
    BSTNode* left;
    BSTNode* right;

    BSTNode(Course* c) : course(c), left(nullptr), right(nullptr) {}
};

// Binary Search Tree class for storing courses
class CourseTree {
public:
    BSTNode* root;

    CourseTree() : root(nullptr) {}

    // Insert a course into the BST
    void insert(Course* newCourse) {
        root = insertRec(root, newCourse);
    }

    // Inorder traversal to get the courses in sorted order
    void inorderPrint() {
        inorderPrintRec(root);
    }

    // Search for a course by its course number
    Course* searchCourse(const std::string& courseNumber) {
        return searchRec(root, courseNumber);
    }

private:
    // Helper function to insert course into the tree
    BSTNode* insertRec(BSTNode* node, Course* newCourse) {
        if (node == nullptr)
            return new BSTNode(newCourse);
        if (newCourse->courseNumber < node->course->courseNumber)
            node->left = insertRec(node->left, newCourse);
        else
            node->right = insertRec(node->right, newCourse);
        return node;
    }

    // Helper function to do inorder traversal and print courses
    void inorderPrintRec(BSTNode* node) {
        if (node != nullptr) {
            inorderPrintRec(node->left);
            std::cout << node->course->courseNumber << ", " << node->course->courseTitle << std::endl;
            inorderPrintRec(node->right);
        }
    }

    // Helper function to search for a course in the BST
    Course* searchRec(BSTNode* node, const std::string& courseNumber) {
        if (node == nullptr)
            return nullptr;
        if (courseNumber == node->course->courseNumber)
            return node->course;
        else if (courseNumber < node->course->courseNumber)
            return searchRec(node->left, courseNumber);
        else
            return searchRec(node->right, courseNumber);
    }
};

// Function to load data from the CSV file into the data structure
void loadData(CourseTree& tree) {
    // Specify the full file path here
    std::string filename = "C:\\Users\\tyeik\\OneDrive\\Documents\\School\\Term 7\\CS-300\\Module 7\\ProjectTwo\\ProjectTwo\\CS 300 ABCU_Advising_Program_Input.csv";

    std::ifstream file(filename);
    std::string line;

    if (!file.is_open()) {
        std::cout << "Error: Could not open the file!" << std::endl;
        return;
    }

    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string courseNum, courseTitle, prereq;

        // Read the course number and title, split by commas
        std::getline(ss, courseNum, ','); // Course number
        std::getline(ss, courseTitle, ','); // Course title

        Course* newCourse = new Course(courseNum, courseTitle);

        // Read and add prerequisites if any
        while (std::getline(ss, prereq, ',')) {
            if (!prereq.empty()) {
                newCourse->addPrerequisite(prereq);
            }
        }

        tree.insert(newCourse);
    }
    file.close();
}

// Function to print the course details including prerequisites
void printCourseDetails(CourseTree& tree, const std::string& courseNumber) {
    Course* course = tree.searchCourse(courseNumber);
    if (course != nullptr) {
        std::cout << "Course Title: " << course->courseTitle << std::endl;
        std::cout << "Prerequisites: ";
        for (const auto& prereq : course->prerequisites) {
            std::cout << prereq << " ";
        }
        std::cout << std::endl;
    }
    else {
        std::cout << "Error: Course not found." << std::endl;
    }
}

// Function to display the menu
void displayMenu() {
    std::cout << "\n1. Load file data into the data structure." << std::endl;
    std::cout << "2. Print alphanumerically ordered course list." << std::endl;
    std::cout << "3. Print course title and prerequisites for an individual course." << std::endl;
    std::cout << "9. Exit the program." << std::endl;
}

// Main function to run the menu and execute actions
int main() {
    CourseTree tree;  // Create the BST to store courses
    int option = 0;
    bool dataLoaded = false;

    do {
        displayMenu();
        std::cout << "What would you like to do? ";
        std::cin >> option;

        switch (option) {
        case 1:
            if (dataLoaded) {
                std::cout << "Data has already been loaded!" << std::endl;
                break;
            }
            // Load the data using the fixed file path
            loadData(tree);
            dataLoaded = true;  // Mark data as loaded
            std::cout << "Data loaded successfully!" << std::endl;
            break;
        case 2:
            if (!dataLoaded) {
                std::cout << "Please load the data first (Option 1)!" << std::endl;
                break;
            }
            std::cout << "Printing sorted course list:" << std::endl;
            tree.inorderPrint();
            break;
        case 3:
            if (!dataLoaded) {
                std::cout << "Please load the data first (Option 1)!" << std::endl;
                break;
            }
            {
                std::string courseNumber;
                std::cout << "Enter the course number you want to know about: ";
                std::cin >> courseNumber;
                printCourseDetails(tree, courseNumber);
                break;
            }
        case 9:
            std::cout << "Thank you for using the advising program!" << std::endl;
            break;
        default:
            std::cout << "Invalid option. Please try again." << std::endl;
            break;
        }

    } while (option != 9);

    return 0;
}
